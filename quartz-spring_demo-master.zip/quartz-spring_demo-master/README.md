quartz-spring_demo
==================

quartz spring结合

项目构建:Maven

Spring+SpringMvc+Mybatis

Mysql

项目启动后访问地址：http://localhost:8080/quartz-spring_demo/task/taskList.htm

http://snailxr.iteye.com/blog/2076903
